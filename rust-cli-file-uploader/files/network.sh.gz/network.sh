docker network create --driver bridge my-custom-net
