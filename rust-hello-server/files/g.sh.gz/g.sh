one=$1

two=$2

read one two 

echo "$one $two"


